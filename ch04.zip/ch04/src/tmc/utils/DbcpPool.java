package tmc.utils;

import java.sql.*;
import java.util.Properties;
import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.dbcp2.BasicDataSourceFactory;
public class DbcpPool { 
		/**
		 * ����JDBC��ض���
		 */
		protected static Statement s=null;
		protected static ResultSet rs = null;
		protected static Connection conn = null;
		private static BasicDataSource dataSource = null;

	    //��ʼ�����ݿ����ӳ�
	    public static void init() 
	    {
	        if (dataSource != null)
	        {
	            try
	            {
	                dataSource.close();
	            } catch (Exception e)
	            {
	                e.printStackTrace();
	            }
	            dataSource = null;
	        }
	        //ʹ��Properties���������ݿ����ӳ���Ϣ
	        try {
	            Properties p = new Properties();
	            p.setProperty("driverClassName", "com.mysql.jdbc.Driver");
	            p.setProperty("url", "jdbc:mysql://localhost:3306/userdb");
	            p.setProperty("username", "root");
	            p.setProperty("password", "123");
	            p.setProperty("maxActive", "30");
	            p.setProperty("maxIdle", "10");
	            p.setProperty("maxWait", "1000");
	            p.setProperty("removeAbandoned", "false");
	            p.setProperty("removeAbandonedTimeout", "120");
	            p.setProperty("testOnBorrow", "true");
	            p.setProperty("logAbandoned", "true");       
	            //��ָ����Ϣ��������Դ
	            dataSource = (BasicDataSource) BasicDataSourceFactory.createDataSource(p);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	    //�����ӳ��л�ȡ����
	    public static synchronized Connection getConnection() throws  SQLException {
	        if (dataSource == null) {
	            init();
	        }
	        Connection conn = null;
	        if (dataSource != null) {
	            conn = dataSource.getConnection();
	        }
	        return conn;
	    }
		
}
